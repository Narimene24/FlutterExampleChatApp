import 'package:flutter/material.dart';

class BrandColor {
  static Color chatInputColor = const Color(0xff1d1c21);
  static Color primaryColor = Colors.deepPurple;
}
