import 'package:google_fonts/google_fonts.dart';

import 'package:flutter/material.dart';

class ThemeTextStyle {
  static TextStyle loginTextFieldStyle =
      GoogleFonts.lato(textStyle: TextStyle(color: Colors.blueGrey));
}
