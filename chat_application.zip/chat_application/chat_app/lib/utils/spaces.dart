import 'package:flutter/material.dart';

Widget verticalSpacing(double val) => SizedBox(height: val);

Widget horizontalSpacing(double val) => SizedBox(width: val);
