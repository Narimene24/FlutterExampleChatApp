import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

// Avoid errors caused by flutter upgrade.
// Importing 'package:flutter/widgets.dart' is required.

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final database = openDatabase(      // Open the database and store the reference.
    join(await getDatabasesPath(), 'doggie_database.db'),
    onCreate: (db, version) {
      return db.execute(
        'CREATE TABLE dogs(id INTEGER PRIMARY KEY, name TEXT, age INTEGER)',);},
    version: 1,
  );

  // Set the version. This executes the onCreate function and provides a
  // path to perform database upgrades and downgrades.

  // Define a function that inserts dogs into the database
  Future<void> insertDog(Dog dog) async {
    final db = await database;   // Get a reference to the database.
    await db.insert(
      'dogs',
      dog.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,  // `conflictAlgorithm` to use in case the same dog is inserted twice.
    );
  }

  // A method that retrieves all the dogs from the dogs table.
  // Get a reference to the database.

  Future<List<Dog>> dogs() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('dogs');     // Query the table for all The Dogs.
    return List.generate(maps.length, (i) {          // Convert the List<Map<String, dynamic> into a List<Dog>.
      return Dog(
        id: maps[i]['id'],
        name: maps[i]['name'],
        age: maps[i]['age'],
      );
    });
  }

  Future<void> updateDog(Dog dog) async {
    final db = await database;         // Get a reference to the database.
    await db.update(             // Update the given Dog.
    'dogs',
      dog.toMap(),
      where: 'id = ?',    // Ensure that the Dog has a matching id.
      whereArgs: [dog.id],         // Pass the Dog's id as a whereArg to prevent SQL injection.
    );
  }


  // Remove the Dog from the database.
  Future<void> deleteDog(int id) async {
    final db = await database;
    await db.delete(
    'dogs',
      where: 'id = ?',           // Use a `where` clause to delete a specific dog.
      whereArgs: [id],             // Pass the Dog's id as a whereArg to prevent SQL injection.
    );
  }




  //-----------Tester
  // Create a Dog and add it to the dogs table
  var fido = const Dog(
    id: 0,
    name: 'Fido',
    age: 35,
  );

  await insertDog(fido);

  // Now, use the method above to retrieve all the dogs.
  print(await dogs()); // Prints a list that include Fido.

  // Update Fido's age and save it to the database.
  fido = Dog(
    id: fido.id,
    name: fido.name,
    age: fido.age + 7,
  );
  await updateDog(fido);

  // Print the updated results.
  print(await dogs()); // Prints Fido with age 42.

  // Delete Fido from the database.
  await deleteDog(fido.id);

  // Print the list of dogs (empty).
  print(await dogs());
}

class Dog {
  final int id;
  final String name;
  final int age;

  const Dog({
    required this.id,
    required this.name,
    required this.age,
  });

  // Convert a Dog into a Map. The keys must correspond to the names of the
  // columns in the database.
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'age': age,
    };
  }

  // Implement toString to make it easier to see information about
  // each dog when using the print statement.
  @override
  String toString() {
    return 'Dog{id: $id, name: $name, age: $age}';
  }
}