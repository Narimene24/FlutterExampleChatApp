package com.poojabhaumik.chat_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
